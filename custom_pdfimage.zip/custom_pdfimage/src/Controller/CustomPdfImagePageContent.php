<?php

namespace Drupal\custom_pdfimage\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use setasign\Fpdi\Fpdi;
use setasign\Fpdi\PdfReader;
/**
 * Class CustomPdfImagePageContent.
 */
class CustomPdfImagePageContent extends ControllerBase {

  /**
   * It will return html data.
   *
   * @return html
   *   Return html output.
   */
  public function content() {
    if( custom_pdfimage_library_exists()){

      $connection = \Drupal::database();
      $nids = $connection->query("SELECT DISTINCT(pfp.play_nid), nfp.field_pdf_target_id FROM {PicturesPdf} pfp 
	                              INNER JOIN node__field_pdf nfp ON nfp.entity_id = pfp.play_nid WHERE moved_to_pdf = 'false'");
      $count = 0;
      foreach($nids as $nid){
        if(!empty($nid->play_nid)){
          $node_storage = \Drupal::entityManager()->getStorage('node');
          $play_node = $node_storage->load($nid->play_nid);
	  //$play_node->set('title', 'test');
	  //$play_node->save();
	  $field_app_pdf =  $play_node->get('field_app_pdf')->getValue();
	  $destination = '';
	  if(empty($field_app_pdf)){
	    $fid = $nid->field_pdf_target_id;
	    $file = file_load($fid);
	    $realFullPathToPDF = drupal_realpath($file->getFileUri());
	    $fileName = $file->getFileName();
	    $files = $play_node->field_app_pdf;
	    $dfSettings = $files->getDataDefinition()->getSettings();
   	    $folder = $dfSettings['uri_scheme'].'://'.$dfSettings['file_directory'].'/';  
  	    $folder = \Drupal::token()->replace($folder);
            if (!file_exists($folder)) {
              mkdir($folder, 0775, true);
            }
	    $destination = $dfSettings['uri_scheme'].'://'.$dfSettings['file_directory'].'/'.$fileName;
	    $destination = \Drupal::token()->replace($destination);
	    $realSavePathToPDF = drupal_realpath($destination);
	  }
          else{
  	    $fid = $field_app_pdf['0']['target_id'];
	    $file = file_load($fid);
            $realFullPathToPDF = drupal_realpath($file->getFileUri());
	    $realSavePathToPDF = drupal_realpath($file->getFileUri());
	  }
          $result = $connection->query("SELECT picture_name,page_no FROM {PicturesPdf}  WHERE moved_to_pdf = 'false' AND play_nid ='$nid->play_nid'");
	  $changed_page = array();
	  foreach($result as $res){
	    $changed_page[$res->page_no] = $res->picture_name;
          }
	  if((!empty($changed_page)) && (file_exists($realFullPathToPDF))){
            $file = file($realFullPathToPDF);
            $endfile= trim($file[count($file) - 1]);
            $n="%%EOF";
            $flaga = 1;
            if ($endfile === $n) {
              $flaga = 1;
            } 
            else {
              $flaga = 2;
              $count--;
            }
	    if($flaga == 1) {
              $pdf = new Fpdi();   
	      $pageCount = $pdf->setSourceFile($realFullPathToPDF);
              for ($i = 1; $i <= $pageCount; $i++) {
                $pdf->AddPage('L','A3');
                $imported = $pdf->importPage($i);
                $pdf->useTemplate($imported);
		if(!empty($changed_page[$i])){
		  if(file_exists(drupal_realpath('public://pdfimage/'.$changed_page[$i]))) {
		    $realFullPathToImage = drupal_realpath('public://pdfimage/'.$changed_page[$i]);
		    $pdf->Image($realFullPathToImage, 0, 0, 430, 290, 'jpg');
		  }
		}
	      }
              $pdf->Output($realSavePathToPDF, 'F');
              $updated = $connection->query("UPDATE {PicturesPdf} SET  moved_to_pdf = 'true' WHERE  play_nid ='$nid->play_nid'");
              //$pdf->Output();
	      if(empty($field_app_pdf)){
		$data = file_get_contents($realSavePathToPDF);
		$file = file_save_data($data, $destination, FILE_EXISTS_REPLACE);
		if(!empty($file)){
		  $play_node->set('field_app_pdf', $file->id());
  		  $play_node->save();
		}
	      }
	    }
	  }
          $count++;
	} //Check Play Exist End
      } // For Nid End
      return [
        'pageview_count' => [
          '#markup' => 'Added image to '.$count.' nodes',
          '#prefix' => '<div class="pageview_count">',
          '#suffix' => '</div>',
        ],
      ];

    } // Lib Check End
  } //Func End
} //Class End
